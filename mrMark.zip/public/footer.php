<div style="height: 200px" class="container-fluid my-footer text-white text-center footerimage">
    <p>all copy right @ megasells corporation</p>
        <a href="https://www.linkedin.com/in/sandeep-prajapati-391604218/">
            <img src="img/linkedin3.png" style="width: 20px" class= "m-4" alt="">
        </a>
</div>