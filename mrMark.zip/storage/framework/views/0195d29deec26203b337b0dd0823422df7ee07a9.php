<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>Mega Offers</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    include "navBar.php";
    ?>
    <div class="container-fluid">
    <?php if(Session('status')): ?>
        <div class="alert alert-success"><?php echo e(Session('status')); ?></div>
        <?php endif; ?>
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card m-3">
                    <img src="<?php echo e(asset('uploads/product/'.$products->img)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h1 class="card-title">
                            <?php echo e($products->title); ?>

                        </h1>
                        <p class="card-text">
                        <?php echo e($products->dirciption); ?>

                        </p>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                        <?php echo e($products->price); ?>

                        </li>
                        <li class="list-group-item">
                        <?php echo e($products->minimum); ?>

                        </li>
                        <li class="list-group-item">
                        <?php echo e($products->address); ?>

                        </li>
                        <div class="row">
                            <div class="col-sm-6 text-center">
                                <?php echo e($products->course); ?>

                            </div>
                            <div class="col-sm-6 text-center">
                            <?php echo e($products->year); ?>

                            </div>
                        </div>
                    </ul>

                    <div class="card-body">
                        <!-- <a href="yourCardUpdate.php" class="card-link">update</a> -->
                        <a href="<?php echo e(url('delete/'.$products->title)); ?>" class="card-link">delete</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
    </div>



    <!-- footer -->
    <?php
include "footer.php";
?>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\mrMark\resources\views/products.blade.php ENDPATH**/ ?>